/**
 * Jun Nguyen
 * October 17, 2020
 * CSE 154 AB AU20 - Austin Jenchi
 *
 * This is the script for my visual novel.
 * It will be where I script the player's progress through the story.
 */

"use strict";
(function() {
  window.addEventListener("load", init);

  /**
   * Run on page load. Sets up the event listeners to start and progress through the visual novel.
   */
  function init() {
    id("start-btn").addEventListener("click", startGame);
    id("intro").addEventListener("click", remove);
    id("intro").addEventListener("click", pickCharacter);
    id("options").addEventListener("click", remove);
    id("options").addEventListener("click", preface);
  }

  /**
   * Saves the player's name, removes the start menu, then plays the welcome message.
   */
  function startGame() {
    let playerName = id("name").value;
    removeStart();
    welcomeMessage(playerName);
  }

  /**
   * Helper function to remove the start menu.
   */
  function removeStart() {
    let startMenu = id("beginning");
    startMenu.parentElement.removeChild(startMenu);
  }

  /**
   * Creates a welcome message for the player when they enter their name.
   * @param {string} playerName - The player's name from the input box.
   */
  function welcomeMessage(playerName) {
    let welcome = gen("article");
    welcome.classList.add("welcome");
    let message = gen("p");
    if (playerName === "" || playerName === "Enter your name") {
      message.textContent = "Welcome to Secret Plot!";
    } else {
      message.textContent = "Welcome to Secret Plot, " + playerName + "!";
    }
    welcome.appendChild(message);
    id("intro").appendChild(welcome);
  }

  /**
   * Helper function to remove the welcome message after it has been clicked on.
   */
  function remove() {
    this.parentNode.removeChild(this);
  }

  /**
   * Shows the character options after the player moves off the welcome message.
   */
  function pickCharacter() {
    show("options");
  }

  /**
   * Shows the preface after the player picks a character.
   */
  function preface() {
    show("preface");
  }

  /**
   * Helper function to show hidden parts in the story
   * @param {string} hidden - The ID of the hidden part
   */
  function show(hidden) {
    let showThis = id(hidden);
    showThis.style.display = "block";
  }

  /**
   * Returns the DOM element with the given ID.
   * @param {string} idName - The ID to find.
   * @returns {object} DOM object associated with id (null if not found).
   */
  function id(idName) {
    return document.getElementById(idName);
  }

  /**
   * Returns a new element that is generated from the given element type.
   * @param {string} elType - HTML element type for new DOM element.
   * @returns {object} New DOM object for given HTML tag.
   */
  function gen(elType) {
    return document.createElement(elType);
  }
})();