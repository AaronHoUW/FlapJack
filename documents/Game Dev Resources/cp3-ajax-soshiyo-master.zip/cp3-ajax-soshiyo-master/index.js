/**
 * Jun Nguyen
 * October 28, 2020
 * CSE 154 AB AU20 - Austin Jenchi
 *
 * This is the script for my visual novel.
 * It will be where I script the player's progress through the story. Allows the player to play
 * a Pokemon gacha after they finish the prologue. Player gets options to respond to the characters'
 * dialogue.
 */

"use strict";
(function() {
  const BASE_URL = "https://pokeapi.co/api/v2/pokemon";
  const TOTAL_POKEMON = 893;

  // This dialogue and the speech timer was inspired by Sven Hansen's summer 2019 About Me page.
  const PROLOGUE_PT1 = [
    "I'm sorry to inform you that you did not get the job.",
    "Huh? Wha- wait a minute. Can you explain the reason?",
    "My apologies, you just don't fit the qualifications of what we're looking for.",
    "O-oh. I see.",
    "I'm sorry. If you'll excuse me.",
    "*click*",
    "...",
    "Haah, another interview failed.",
    "It looks like it's time to keep job hunting.",
    "Wait...uh oh! I'm gonna be late for class!",
    "*huff* *huff*",
    "Wow, you look like you just ran a marathon. Do you need some water?",
    "Wha- oh hi Zen! Uh no, it's okay but thank you!",
    "Did that company tell you if you got the job yet?",
    "Yeah...they just called me earlier.",
    "Oh! How did it go?",
    "...I didn't get the job.",
    "Oh...I'm sorry to hear that. I'm sure you'll get the next one.",
    "Thanks, Zen. I hope so.",
    "Do you have plans after this?",
    "Huh? No, I don't think so.",
    "Let's go to the usual cafe, then.",
    "Are you craving again?",
    "Maybe, but I know you're craving it, too.",
    "Then let's go!",
    "U-um...can I go with you guys too?",
    "Huh? Oh! Ruki, of course you can!",
    "Who's this?",
    "Oh, let me introduce you guys. Zen, this is Ruki. He's a year younger than me.",
    "And Ruki, this is Zen. He's a year older than me.",
    "It's nice to meet you, Ruki.",
    "I-it's nice to meet you too.",
    "*ding* *ding* *ding* *ding*",
    "Oh! That was the bell! Let's go let's go let's go!!",
    "Haha calm down. The cafe isn't going anywhere.",
    "But it's gonna be crowded!",
    "Ruki, are you good to go?",
    "Y-yes. Let's go.",
    "Hey! Don't ignore me...",
    "Don't worry, it'll be fine.",
    "Well...if Zen says so then I guess it's fine.",
    "*ding*",
    "Hello, what would you three like to drink today?",
    "Do you guys already know what you want?",
    "Y-yes.",
    "Of course!",
    "Then you can order first."
  ];

  const ZEN = "Zen";
  const RUKI = "Ruki";
  const PLAYER = "Player";

  const SPEAKER = [
    "Manager", PLAYER, "Manager", PLAYER, "Manager", "", PLAYER, PLAYER, PLAYER, PLAYER,
    "", ZEN, PLAYER, ZEN, PLAYER, ZEN, PLAYER, ZEN, PLAYER, ZEN, PLAYER, ZEN, PLAYER, ZEN,
    PLAYER, RUKI, PLAYER, ZEN, PLAYER, PLAYER, ZEN, RUKI, "", PLAYER, ZEN, PLAYER, ZEN, RUKI,
    PLAYER, ZEN, PLAYER, "", "Barista", ZEN, RUKI, PLAYER, ZEN
  ];

  const TALK_SPEED = 10;

  let speechTimer = 0;

  window.addEventListener("load", init);

  /**
   * Run on page load. Sets up the event listeners to start and progress through the visual novel.
   */
  function init() {
    let position = 0;

    id("start-btn").addEventListener("click", startGame);
    id("intro").addEventListener("click", remove);
    id("intro").addEventListener("click", toggleDialogue);

    id("dialogue-box").addEventListener("click", () => firstDialogue(position++));
    id("drinks").addEventListener("click", remove);
    id("drinks").addEventListener("click", () => show("continue"));
    id("drinks").addEventListener("click", function() {
      id("game").classList.remove("room-bg");
      id("game").classList.remove("cafe-bg");
      id("game").classList.add("start-bg");
    });

    id("continue").addEventListener("click", remove);
    id("continue").addEventListener("click", () => show("chara-options"));
    id("chara-options").addEventListener("click", remove);
    id("chara-options").addEventListener("click", () => show("catch"));

    id("catch").addEventListener("click", remove);
    id("catch").addEventListener("click", () => show("gacha-screen"));
    id("one-roll").addEventListener("click", makeRequest);
    id("one-roll").addEventListener("click", () => hide("gacha-screen"));
    id("one-roll").addEventListener("click", () => show("results"));

    id("back-btn").addEventListener("click", () => show("gacha-screen"));
    id("back-btn").addEventListener("click", () => hide("results"));
    id("back-btn").addEventListener("click", function() {
      id("card-display").removeChild(qs(".poke-image"));
    });
  }

  /**
   * Make request to fetch data from the Pokemon API. Randomizes a pokemon from the total
   * and fetches data of that pokemon.
   */
  function makeRequest() {
    let random = parseInt(Math.random() * TOTAL_POKEMON);
    let url = BASE_URL + "/" + random;
    fetch(url)
      .then(checkStatus)
      .then(resp => resp.json())
      .then(processData)
      .catch(handleRequestError);
  }

  /**
   * Process the response data requested. Utilize the pokemon's data and display it on the page.
   * @param {object} pokemon - The pokemon to get data from.
   */
  function processData(pokemon) {
    qs(".poke-name").textContent = capitalize(pokemon.name);
    qs(".poke-id").textContent = "#" + pokemon.id;

    let image = gen("img");
    image.classList.add("poke-image");
    image.src = pokemon.sprites["front_default"];
    image.alt = pokemon.name;
    id("card-display").appendChild(image);

    qs(".poke-height").textContent = (pokemon.height / 10) + " m";
    qs(".poke-weight").textContent = (pokemon.weight / 10) + " kg";

    let owned = gen("img");
    owned.classList.add("poke-owned");
    owned.src = pokemon.sprites["front_default"];
    owned.alt = pokemon.name;
    id("pokemon").appendChild(owned);

    let typeList = pokemon.types;
    let firstType = typeList[0];
    let secondType = typeList[1];
    qs(".poke-type-1").textContent = capitalize(firstType.type.name);
    if (secondType) {
      qs(".poke-type-2").classList.remove("hidden");
      qs(".poke-type-2").textContent = capitalize(secondType.type.name);
    } else {
      secondType = "";
    }
  }

  /**
   * Helper function to capitalize the first letter in a string.
   * @param {string} str - String to be capitalized.
   * @returns {string} Resulting string once first letter has been capitalized.
   */
  function capitalize(str) {
    return str[0].toUpperCase() + str.substr(1);
  }

  /**
   * Helper function to return the response's result text if successful, otherwise
   * returns the rejected Promise result with an error status and corresponding text
   * @param {object} res - response to check for success/error
   * @return {object} - valid response if response was successful, otherwise rejected
   *                    Promise result
   */
  async function checkStatus(res) {
    if (!res.ok) {
      throw new Error(await res.text());
    }
    return res;
  }

  /**
   * Handles any errors that arise when fetching for the data.
   */
  function handleRequestError() {
    let message = gen("p");
    message.textContent = "There was an error requesting data from the Pokemon service.";
    id("results").appendChild(message);
  }

  /**
   * Progresses through the dialogue.
   * @param {number} position - The position in the dialogue that the player is at.
   */
  function firstDialogue(position) {
    if (position < PROLOGUE_PT1.length) {
      conversation(PROLOGUE_PT1[position], SPEAKER[position]);
    }

    if (position === PROLOGUE_PT1.length) {
      show("drinks");
      hide("dialogue-box");
      position = 0;
    }

    if (position === 0) {
      id("game").classList.remove("start-bg");
      id("game").classList.add("room-bg");
    }

    if (position === 10) {
      id("game").classList.remove("room-bg");
      id("game").classList.add("school-bg");
    }

    if (position === 41) {
      id("game").classList.remove("school-bg");
      id("game").classList.add("cafe-bg");
    }
  }

  /**
   * Shows the dialogue and makes the characters speak.
   * @param {string} dialogue - The dialogue that the character speaks.
   * @param {string} speaker - The name of the character speaking.
   */
  function conversation(dialogue, speaker) {
    // Note for next CP: Add character appear on screen as they talk
    clearInterval(speechTimer);
    let text = id("text");
    let name = id("chara-name");
    name.textContent = speaker;
    text.textContent = "";
    speechTimer = setInterval(function() {
      if (dialogue.length === 0) {
        clearInterval(speechTimer);
      } else {
        text.textContent = text.textContent + dialogue[0];
        dialogue = dialogue.slice(1, dialogue.length);
      }
    }, TALK_SPEED);
  }

  /**
   * Removes the start menu, then plays the welcome message custom for the player.
   */
  function startGame() {
    let playerName = getPlayerName();
    removeStart();
    welcomeMessage(playerName);
  }

  /**
   * Helper function to get player name value.
   * @returns {string} The player's name.
   */
  function getPlayerName() {
    let playerName = id("name").value;
    return playerName;
  }

  /**
   * Helper function to remove the start menu.
   */
  function removeStart() {
    let startMenu = id("beginning");
    startMenu.parentElement.removeChild(startMenu);
  }

  /**
   * Creates a welcome message for the player when they enter their name.
   * @param {string} playerName - The player's name from the input box.
   */
  function welcomeMessage(playerName) {
    let welcome = gen("article");
    welcome.classList.add("welcome");
    let message = gen("p");
    if (playerName === "" || playerName === "Enter your name") {
      message.textContent = "Welcome to Secret Plot!";
    } else {
      message.textContent = "Welcome to Secret Plot, " + playerName + "!";
    }
    welcome.appendChild(message);
    id("intro").appendChild(welcome);
  }

  /**
   * Helper function to remove the element after it has been clicked on.
   */
  function remove() {
    this.parentNode.removeChild(this);
  }

  /**
   * Toggles the dialogue box. If it is hidden, make it visible, and vice versa.
   */
  function toggleDialogue() {
    if (!id("dialogue-box").classList.contains("hidden")) {
      hide("dialogue-box");
    } else {
      show("dialogue-box");
      id("text").textContent = "";
      id("chara-name").textContent = "";
    }
  }

  /**
   * Helper function to hide parts in the story.
   * @param {string} hiddenBox - The ID of the object to hide.
   */
  function hide(hiddenBox) {
    id(hiddenBox).classList.add("hidden");
  }

  /**
   * Helper function to show hidden parts in the story.
   * @param {string} hiddenBox - The ID of the hidden part
   */
  function show(hiddenBox) {
    id(hiddenBox).classList.remove("hidden");
  }

  /**
   * Returns the DOM element with the given ID.
   * @param {string} idName - The ID to find.
   * @returns {object} DOM object associated with id (null if not found).
   */
  function id(idName) {
    return document.getElementById(idName);
  }

  /**
   * Returns first element matching selector.
   * @param {string} selector - CSS query selector.
   * @returns {HTMLElement} - DOM object associated selector.
   */
  function qs(selector) {
    return document.querySelector(selector);
  }

  /**
   * Returns a new element that is generated from the given element type.
   * @param {string} elType - HTML element type for new DOM element.
   * @returns {object} New DOM object for given HTML tag.
   */
  function gen(elType) {
    return document.createElement(elType);
  }
})();