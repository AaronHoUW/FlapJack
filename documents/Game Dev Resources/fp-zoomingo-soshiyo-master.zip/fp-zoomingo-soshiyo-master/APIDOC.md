# Zoomingo API Documentation
The Zoomingo API saves the player's game state and information, allowing them to play new games or resume old games.

## New Game Endpoint
**Request Format:** /newGame

**Request Type:** GET

**Returned Data Format**: JSON

**Query Parameters:** `name`, `size`

**Description:** Gets a new Bingo board for the player with random scenarios.

**Example Request:** /newGame?size=9&name=Jun

**Example Response:**

```json
{
  "game_id": 160,
  "player": {
    "id": 59,
    "name": "Jun",
    "board": [
      {"id": 1, "text": "FREE"},
      {"id": 18, "text": "Any questions? *silence* Anyone?"}
      ...
    ]
  }
}
```

**Error Handling:**
- Possible 500 (internal server error) errors (all plain text):
  - If any problems occur, an error is returned with the message: `Something went wrong on the server.`

## Select Scenarios Endpoint
**Request Format:** /selectScenarios

**Request Type:** POST

**Returned Data Format**: JSON

**Query Parameters:** `game_id`, `scenario_id`

**Description:** Updates the database with the player's selected scenario.

**Example Request:** /selectScenarios with POST parameters of `game_id=160` and `scenario_id=13`

**Example Response:**
```json
{
  "game_id": 160,
  "scenario_id": 13
}
```

**Error Handling:**
- Possible 500 (internal server error) errors (all plain text):
  - If any other problems occur, an error is returned with the message: `Something went wrong on the server.`
- Possible 400 (invalid request) errors (JSON format):
  - If the scenario is not in the player's list of given scenarios, an error is returned:

***Example Error Message***
```json
{
  "error": "Could not select scenario ID: 999"
}
```

## Bingo Endpoint
**Request Format:** /bingo

**Request Type:** POST

**Returned Data Format**: JSON

**Query Parameters:** `game_id`

**Description:** Determines if the player can win the game or not.

**Example Request:** /bingo with POST parameters of `game_id=160`

**Example Response:**
```json
{
  "game_id": 160,
  "winner": "Jun"
}
```

**Error Handling**
- Possible 500 (internal server error) errors (all plain text):
  - If any other problems occur, an error is returned with the message: `Something went wrong on the server.`
- Possible 400 (invalid request) errors (JSON format):
  - If the game has already been won, an error is returned:

***Example Error Message***
```json
{
  "error": "Game has already been won."
}
```

## Resume Game Endpoint
**Request Format:** /resumeGame

**Request Type:** GET

**Returned Data Format**: JSON

**Query Parameters:** `game_id`, `player_id`

**Description:** Gets the current game state for the given game ID.

**Example Request:** /resumeGame?game_id=160&player_id=59

**Example Response:**
```json
{
  "game_id": 160,
  "player": {
    "id": 59,
    "name": "Jun",
    "board": [
      {"id": 1, "text": "FREE"},
      {"id": 18, "text": "Any questions? *silence* Anyone?"}
      ...
    ],
    "selected_scenarios": [
      19,
      4,
      ...
    ]
  }
}
```

**Error Handling**
- Possible 500 (internal server error) errors (all plain text):
  - If any other problems occur, an error is returned with the message: `Something went wrong on the server.`
- Possible 400 (invalid request) errors (JSON format):
  - If the given player ID is not part of the database, an error is returned:

***Example Error Message***
```json
{
  "error": "Cannot resume game: Player 999 was not part of game 160"
}
```