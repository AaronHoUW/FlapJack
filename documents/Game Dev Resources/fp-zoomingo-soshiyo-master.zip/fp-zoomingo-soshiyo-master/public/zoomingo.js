/**
 * Jun Nguyen
 * November 22, 2020
 * CSE 154 AB AU20 - Austin Jenchi
 *
 * This is the frontend (or "client side") for the Zoomingo website. It allows the user to play
 * a game of Bingo, Zoom edition. They can pick the size of their boards, play the game, reset
 * the game, and resume the game.
 */
"use strict";

(function() {
  window.addEventListener("load", init);

  /**
   * Runs on page load. Sets up the website to allow the user to interact with the game.
   * Updates the page when the player plays the game.
   */
  function init() {
    id("new-game").addEventListener("click", () => {
      id("new-game").disabled = true;
      disableOptions(true);
    });

    id("bingo").addEventListener("click", () => {
      disableOptions(false);
    });

    id("reset").addEventListener("click", () => {
      disableOptions(false);
      hideText();
      id("error").textContent = "Error: Please select a board size and/or enter a name.";
    });

    id("size-select").addEventListener("change", clearBoard);
    id("size-select").addEventListener("change", () => {
      let totalSquares = getSquareNumber();
      displayBoard(totalSquares);
    });

    id("new-game").addEventListener("click", newGame);
    id("reset").addEventListener("click", resetBoard);
    id("bingo").addEventListener("click", callBingo);

    let gameID = window.localStorage.getItem("game_id");
    let playerID = window.localStorage.getItem("player_id");
    if (gameID !== null || playerID !== null) {
      id("resume").disabled = false;
      id("resume").addEventListener("click", resumeGame);
    }
  }

  /**
   * Resumes the game when the player clicks the button.
   */
  function resumeGame() {
    let gameID = window.localStorage.getItem("game_id");
    let playerID = window.localStorage.getItem("player_id");
    let url = "/resumeGame?game_id=" + gameID + "&player_id=" + playerID;
    fetchGet(url, showResumedGame);
  }

  /**
   * Displays the board, scenarios, and the selected scenarios of the game that the player wants
   * to resume. Allows the player to continue playing.
   * @param {object} res - The data of the game that the player wants to resume.
   */
  function showResumedGame(res) {
    clearBoard();
    let board = res.player.board;
    let boardSize = board.length;
    let selectedScenarios = res.player.selected_scenarios;
    displayBoard(boardSize);
    displayScenarios(boardSize, board);
    selectedScenarios.forEach(element => {
      id(element).classList.add("selected");
    });
    id("name").value = res.player.name;
    id("size-select").value = boardSize;
  }

  /**
   * Hides the success and error messages.
   */
  function hideText() {
    qs("main > p").classList.add("hidden");
    qs("main >p").nextElementSibling.classList.add("hidden");
    id("error").classList.add("hidden");
  }

  /**
   * When the player clicks the button, see if the player is able to win or not.
   */
  function callBingo() {
    let gameID = window.localStorage.getItem('game_id');
    let params = new FormData();
    params.append("game_id", gameID);
    fetchPost("/bingo", params, showWinner);
  }

  /**
   * Shows the winner of the game. Depending on if the player wins or not, it shows a message
   * either congratulating them or telling them no one has won yet. If the player wins, then stops
   * the game.
   * @param {object} res - The data of the current winner of this game.
   */
  function showWinner(res) {
    let winText = qs("main > p");
    let noWinText = qs("main > p").nextElementSibling;
    if (res.winner !== null) {
      showWinText(winText, noWinText);
      qsa(".scenario").forEach(element => {
        element.removeEventListener("click", selectedScenario);
      });
    } else {
      showWinText(noWinText, winText);
      setTimeout(() => {
        noWinText.classList.add("hidden");
      }, 2000);
    }
  }

  /**
   * Helper function to show and hide a winner text. A winner text is either a message that says
   * the player won or a message that says nobody has won. Neither is shown at the same time.
   * @param {HTMLElement} show - Element to be shown.
   * @param {HTMLElement} hide - Element to be hidden.
   */
  function showWinText(show, hide) {
    show.classList.remove("hidden");
    hide.classList.add("hidden");
  }

  /**
   * Updates the page when a player selects a scenario.
   */
  function selectedScenario() {
    let gameID = window.localStorage.getItem('game_id');
    let params = new FormData();
    params.append("game_id", gameID);
    params.append("scenario_id", this.id);
    fetchPost("/selectScenarios", params, showSelected);
  }

  /**
   * Helper function to do a fetch data through the post method and return it in JSON format.
   * @param {string} url - The url to fetch data from.
   * @param {object} params - The parameters to send to the server.
   * @param {function} process - Uses the response data and processes it.
   */
  function fetchPost(url, params, process) {
    fetch(url, {method: "POST", body: params})
      .then(checkStatus)
      .then(res => res.json())
      .then(process)
      .catch(handleError);
  }

  /**
   * Shows the selected scenario if it is valid. Displays error message if not.
   * @param {object} res - The data of the selected scenario.
   */
  function showSelected(res) {
    let scenarioID = Number(res.scenario_id);
    let selected = id(scenarioID);
    selected.classList.add("selected");
    id("error").classList.add("hidden");
    id(scenarioID).removeEventListener("click", selectedScenario);
  }

  /**
   * Resets the board and clears the local data.
   */
  function resetBoard() {
    id("new-game").disabled = false;
    disableOptions(false);
    id("board").innerHTML = "";
    window.localStorage.clear();
    id("error").classList.add("hidden");
  }

  /**
   * Creates a new game and displays the board with scenarios to the player.
   */
  function newGame() {
    hideText();
    let size = id("size-select").value;
    let name = id("name").value;
    if (!size || !name) {
      disableOptions(false);
      id("error").classList.remove("hidden");
      clearBoard();
    } else {
      clearBoard();
      id("error").classList.add("hidden");
      displayBoard(size);
      let url = "/newGame?size=" + size + "&name=" + name;
      fetchGet(url, inputScenarios);
    }
  }

  /**
   * Helper function to fetch data and return it in JSON format.
   * @param {string} url - The url to fetch data from.
   * @param {function} process - Uses the response data and processes it.
   */
  function fetchGet(url, process) {
    fetch(url)
      .then(checkStatus)
      .then(res => res.json())
      .then(process)
      .catch(handleError);
  }

  /**
   * Inputs and displays the scenarios of the new game onto the board.
   * @param {object} res - The data containing the game data.
   */
  function inputScenarios(res) {
    let size = id("size-select").value;
    let boardLength = res.player.board.length;
    let board = res.player.board;
    if (Number(boardLength) !== Number(size)) {
      id("error").textContent = "Not enough scenarios.";
      id("error").classList.remove("hidden");
    } else {
      displayScenarios(size, board);
      setLocalStorage(res.game_id, res.player.id);
    }
  }

  /**
   * Sets the local storage keys and values for the new game.
   * @param {number} gameID - The ID of the new game.
   * @param {number} playerID - The ID of the player.
   */
  function setLocalStorage(gameID, playerID) {
    window.localStorage.setItem('game_id', JSON.stringify(gameID));
    window.localStorage.setItem('player_id', JSON.stringify(playerID));
  }

  /**
   * Displays the scenarios on the board with the FREE space in the middle.
   * @param {string} size - The size of the board.
   * @param {object} content - The content of the board (id and text).
   */
  function displayScenarios(size, content) {
    let scenarios = qsa(".scenario");
    let half = parseInt(Number(size) / 2);
    let placeholder = 1;
    scenarios[half].textContent = content[0].text;
    scenarios[half].id = content[0].id;
    for (let i = 0; i < content.length; i++) {
      if (i === half) {
        i++;
      }
      scenarios[i].textContent = content[placeholder].text;
      scenarios[i].id = content[placeholder].id;
      placeholder++;
    }
  }

  /**
   * Helper function to get the board size of the game.
   * @returns {number} The number of squares needed for the game.
   */
  function getSquareNumber() {
    let squares = id("size-select").value;
    return squares;
  }

  /**
   * Clears the board.
   */
  function clearBoard() {
    let board = id("board");
    while (board.firstChild) {
      board.removeChild(board.firstChild);
    }
  }

  /**
   * Displays the board based on the total number of squares needed. Adds interactivity to each
   * square.
   * @param {string} totalSquares - The total number of squares needed on the board.
   */
  function displayBoard(totalSquares) {
    let rows = Math.sqrt(Number(totalSquares));
    for (let i = 0; i < totalSquares; i++) {
      let square = gen("div");
      let scenario = gen("p");
      createRows(rows, square);
      square.classList.add("square");
      scenario.classList.add("scenario");

      square.appendChild(scenario);
      id("board").appendChild(square);
    }
    qsa(".scenario").forEach(element => {
      element.addEventListener("click", selectedScenario);
    });
  }

  /**
   * Creates the rows for each board size.
   * @param {number} rows - The number of rows needed.
   * @param {HTMLElement} square - The container of the square.
   */
  function createRows(rows, square) {
    if (rows === 3) {
      square.classList.add("three");
    } else if (rows === 5) {
      square.classList.add("five");
    } else if (rows === 7) {
      square.classList.add("seven");
    } else {
      square.classList.add("nine");
    }
  }

  /**
   * Disables or enables the name and size select options.
   * @param {boolean} tf - True or false.
   */
  function disableOptions(tf) {
    id("name").disabled = tf;
    id("size-select").disabled = tf;
  }

  /**
   * Handles the possible errors returned by the API. If an error occurs, show the error text.
   * @param {object} error - The object that contains the error.
   */
  function handleError(error) {
    let errMessage = JSON.parse(error.message);
    id("error").classList.remove("hidden");
    id("error").textContent = errMessage.error;
  }

  /**
   * Helper function to return the response's result text if successful, otherwise
   * returns the rejected Promise result with an error status and corresponding text
   * @param {object} res - response to check for success/error
   * @return {object} - valid response if response was successful, otherwise rejected
   *                    Promise result
   */
  async function checkStatus(res) {
    if (!res.ok) {
      throw new Error(await res.text());
    }
    return res;
  }

  /**
   * Returns the DOM element with the given ID.
   * @param {string} idName - The ID to find.
   * @returns {object} DOM object associated with id (null if not found).
   */
  function id(idName) {
    return document.getElementById(idName);
  }

  /**
   * Returns first element matching selector.
   * @param {string} selector - CSS query selector.
   * @returns {HTMLElement} - DOM object associated selector.
   */
  function qs(selector) {
    return document.querySelector(selector);
  }

  /**
   * Returns the array of elements that match the given CSS selector.
   * @param {string} query - CSS query selector
   * @returns {object[]} array of DOM objects matching the query.
   */
  function qsa(query) {
    return document.querySelectorAll(query);
  }

  /**
   * Returns a new element that is generated from the given element type.
   * @param {string} elType - HTML element type for new DOM element.
   * @returns {object} New DOM object for given HTML tag.
   */
  function gen(elType) {
    return document.createElement(elType);
  }
})();