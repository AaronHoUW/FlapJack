/**
 * Jun Nguyen
 * November 22, 2020
 * CSE 154 AB AU20 - Austin Jenchi
 *
 * This is the backend (or "server side") for the Zoomingo website, where the
 * user's data and state of their games are stored in a database. It sends the player a bingo
 * game and game data for if they want to resume playing, and updates the database during the game.
 */
"use strict";

const express = require("express");
const sqlite = require("sqlite");
const sqlite3 = require("sqlite3");
const app = express();
const multer = require("multer");

// for application/x-www-form-urlencoded
app.use(express.urlencoded({extended: true})); // built-in middleware
// for application/json
app.use(express.json()); // built-in middleware
// for multipart/form-data (required with FormData)
app.use(multer().none()); // requires the "multer" module

const SERVER_ERROR_CODE = 500;
const CLIENT_ERROR_CODE = 400;
const SERVER_ERROR_MESSAGE = "Something went wrong on the server.";

/**
 * Generates a new board for the player with the appropriate size. Sends the data of this new
 * board from the database back to the user.
 */
app.get("/newGame", async function(req, res) {
  try {
    let size = req.query.size;
    let name = req.query.name;
    let gameID = await gameQuery();
    let playerID = await playerQuery(name);
    let scenarios = await getScenarios(size);
    await boardQuery(gameID, playerID, scenarios);
    let game = createGame(gameID, playerID, name, scenarios);
    res.json(game);
  } catch (err) {
    res.type("text")
      .status(SERVER_ERROR_CODE)
      .send(SERVER_ERROR_MESSAGE);
  }
});

/**
 * Updates the database when the player selects a scenario. Checks to make sure the scenario is
 * valid and sends back the data of the game and selected scenario.
 */
app.post("/selectScenarios", async function(req, res) {
  let gameID = req.body.game_id;
  let scenarioID = req.body.scenario_id;
  try {
    let givenScenarios = await getGivenScenarios(gameID);
    let exist = checkIfExists(givenScenarios, scenarioID);
    if (exist) {
      await addSelected(scenarioID, gameID);
      let success = {
        'game_id': gameID,
        'scenario_id': scenarioID
      };
      res.json(success);
    } else {
      let errorJSON = {
        error: 'Could not select scenario ID: ' + scenarioID
      };
      res.status(CLIENT_ERROR_CODE).json(errorJSON);
    }
  } catch (err) {
    res.type("text")
      .status(SERVER_ERROR_CODE)
      .send(SERVER_ERROR_MESSAGE);
  }
});

/**
 * Checks to see if the player can win or not. Updates the database if the player wins and sends
 * back the data of the game won and the player's name.
 */
app.post("/bingo", async function(req, res) {
  let gameID = req.body.game_id;
  try {
    let scenarioCheck = await checkScenarios(gameID);
    if (scenarioCheck.selected >= Math.sqrt(scenarioCheck.board_size)) {
      let winner = await checkWinner(gameID);
      if (winner !== null) {
        let errorJSON = {
          error: 'Game has already been won.'
        };
        res.status(CLIENT_ERROR_CODE).json(errorJSON);
      } else {
        let playerID = await getPlayerID(gameID);
        await updateWinner(gameID, playerID);
        let playerName = await getPlayerName(playerID);
        let player = getWinner(gameID, playerName);
        res.json(player);
      }
    } else {
      let noWinner = getWinner(gameID, null);
      res.json(noWinner);
    }
  } catch (err) {
    res.type("text")
      .status(SERVER_ERROR_CODE)
      .send(SERVER_ERROR_MESSAGE);
  }
});

/**
 * Gets the game state of the given game ID. If the player ID is valid for this game, then
 * sends back the game state of this game.
 */
app.get("/resumeGame", async function(req, res) {
  let gameID = req.query.game_id;
  let playerID = req.query.player_id;
  try {
    let playerExist = await checkPlayerID(playerID);
    if (playerExist === false) {
      res.status(CLIENT_ERROR_CODE).json({
        error: 'Cannot resume game: Player ' + playerID + ' was not part of game ' + gameID
      });
    } else {
      let gameState = await getGameState(gameID, playerID);
      res.json(gameState);
    }
  } catch (err) {
    res.type("text")
      .status(SERVER_ERROR_CODE)
      .send(SERVER_ERROR_MESSAGE);
  }
});

/**
 * Gets the game state of the current game and creates the board for it.
 * @param {string} gameID - The ID of the current game.
 * @param {string} playerID - The ID of the player.
 * @returns {object} The board object containing the game state of the current game.
 */
async function getGameState(gameID, playerID) {
  const db = await getDBConnection();
  let scenQuery = 'SELECT given_scenario_ids, selected_scenario_ids FROM game_state' +
    ' WHERE game_id = (?);';
  let gameState = await db.all(scenQuery, gameID);
  let nameQuery = 'SELECT name FROM players WHERE id = (?);';
  let name = await db.all(nameQuery, playerID);
  let givenIDs = parseString(gameState[0].given_scenario_ids);
  let selectedIDs = parseString(gameState[0].selected_scenario_ids);
  let givenScenarios = await getResumedScenarios(givenIDs, givenIDs.length);
  let board = await createGame(Number(gameID), Number(playerID), name[0].name, givenScenarios);
  board.player['selected_scenarios'] = selectedIDs;
  await db.close();
  return board;
}

/**
 * Gets all of the scenarios of the current game.
 * @param {object} givenIDs - The list of all given scenario IDs of the current game.
 * @param {number} length - The length of the given scenario IDs list.
 * @returns {array} The list of scenarios of the current game.
 */
async function getResumedScenarios(givenIDs, length) {
  const db = await getDBConnection();
  let list = [];
  for (let i = 0; i < length; i++) {
    let query = 'SELECT * FROM scenarios WHERE id = (?);';
    let data = await db.all(query, givenIDs[i]);
    data = data[0];
    list.push(data);
  }
  await db.close();
  return list;
}

/**
 * Checks the player ID with the database to make sure it exists.
 * @param {string} playerID - The ID of the player.
 * @returns {boolean} Whether or not the player ID exists in the database.
 */
async function checkPlayerID(playerID) {
  const db = await getDBConnection();
  let query = 'SELECT player_id FROM game_state;';
  let list = await db.all(query);
  list = list.map(item => item.player_id);
  let exist = checkIfExists(list, playerID);
  await db.close();
  return exist;
}

/**
 * Creates an object containing the data of the game's winner and returns it.
 * @param {string} gameID - The ID of the game.
 * @param {string} name - The name of the winner.
 * @returns {object} The data of the game's winner.
 */
function getWinner(gameID, name) {
  let win = {
    'game_id': gameID,
    'winner': name
  };
  return win;
}

/**
 * Updates the games table with the winner of a specific game.
 * @param {string} gameID - The ID of the game.
 * @param {string} playerID - The ID of the player.
 */
async function updateWinner(gameID, playerID) {
  const db = await getDBConnection();
  let query = 'UPDATE games SET winner = (?) WHERE id = (?);';
  await db.run(query, [playerID, gameID]);
  await db.close();
}

/**
 * Gets the player's name based on their unique ID.
 * @param {string} playerID - The ID of the player.
 * @returns {string} The name of the player.
 */
async function getPlayerName(playerID) {
  const db = await getDBConnection();
  let query = 'SELECT name FROM players WHERE id = (?);';
  let name = await db.all(query, playerID);
  await db.close();
  return name[0].name;
}

/**
 * Gets the ID of the player from the database for the specific game.
 * @param {string} gameID - The ID of the game.
 * @returns {number} The ID of the player.
 */
async function getPlayerID(gameID) {
  const db = await getDBConnection();
  let query = 'SELECT player_id FROM game_state WHERE game_id = (?);';
  let playerID = await db.all(query, gameID);
  await db.close();
  return playerID[0].player_id;
}

/**
 * Checks if there is a winner for a specific game.
 * @param {string} gameID - The ID of the game.
 * @returns {object} Data of the winner, can be null.
 */
async function checkWinner(gameID) {
  const db = await getDBConnection();
  let winnerQuery = 'SELECT g.winner FROM games g, game_state gs WHERE g.id = gs.game_id AND ' +
    'g.id = (?)';
  let data = await db.all(winnerQuery, gameID);
  let winner = data[0].winner;
  await db.close();
  return winner;
}

/**
 * Checks to see the number of selected scenarios compared to the board size.
 * @param {string} gameID - The ID of the game.
 * @returns {object} The data of the board size and selected scenarios.
 */
async function checkScenarios(gameID) {
  const db = await getDBConnection();
  let query = 'SELECT given_scenario_ids, selected_scenario_ids FROM game_state ' +
    'WHERE game_id = (?);';
  let board = await db.all(query, gameID);
  let given = parseString(board[0].given_scenario_ids);
  let clicked = parseString(board[0].selected_scenario_ids);
  let boardSize = given.length;
  let selectedLength = clicked.length;
  let winnable = {
    'board_size': boardSize,
    'selected': selectedLength
  };
  await db.close();
  return winnable;
}

/**
 * Helper function to parse JSON.
 * @param {string} string - The string to parse.
 * @returns {object} The parsed object.
 */
function parseString(string) {
  let parsed = JSON.parse(string);
  return parsed;
}

/**
 * Checks to see if the selected scenario exists, and adds it to the database if it doesn't.
 * @param {string} scenarioID - The ID of the scenario.
 * @param {string} gameID - The ID of the game.
 */
async function addSelected(scenarioID, gameID) {
  const db = await getDBConnection();
  let select = 'SELECT selected_scenario_ids FROM game_state WHERE game_id = (?);';
  let selectedScenarios = await db.all(select, gameID);
  let exist = checkIfExists(selectedScenarios, scenarioID);
  if (!exist) {
    let scenarios = selectedScenarios[0].selected_scenario_ids;
    scenarios = JSON.parse(scenarios);
    if (!scenarios.includes(Number(scenarioID))) {
      scenarios.push(Number(scenarioID));
      scenarios = JSON.stringify(scenarios);
      await updateList(scenarios, gameID);
    }
  }
  await db.close();
}

/**
 * Updates the database with the selected scenarios.
 * @param {string} list - The list of scenarios selected to update.
 * @param {string} gameID - The ID of the game.
 */
async function updateList(list, gameID) {
  const db = await getDBConnection();
  let update = 'UPDATE game_state SET selected_scenario_ids = (?) WHERE game_id = (?);';
  await db.run(update, [list, gameID]);
  await db.close();
}

/**
 * Checks through a list to see if the ID exists or not within the list.
 * @param {object} list - The list to check through.
 * @param {string} id - The ID to look for.
 * @returns {boolean} - Whether or not the ID exists in the list.
 */
function checkIfExists(list, id) {
  let exist = false;
  if (list && list.length !== 0) {
    list.forEach(element => {
      if (element === Number(id)) {
        exist = true;
      }
    });
  }
  return exist;
}

/**
 * Gets the given scenarios for a specific game and returns a list of them.
 * @param {string} gameID - The ID of the game.
 * @returns {object} The list of given scenarios.
 */
async function getGivenScenarios(gameID) {
  const db = await getDBConnection();
  let query = 'SELECT given_scenario_ids FROM game_state WHERE game_id = (?);';
  let scenarios = await db.all(query, gameID);
  scenarios = JSON.parse(scenarios[0].given_scenario_ids);
  await db.close();
  return scenarios;
}

/**
 * Creates a new game state in the database when a new game is asked for.
 * @param {string} gameID - The ID of the game.
 * @param {string} playerID - The ID of the player.
 * @param {object} scenarios - The list of scenarios.
 */
async function boardQuery(gameID, playerID, scenarios) {
  const db = await getDBConnection();
  let newBoard = 'INSERT INTO game_state (game_id, player_id, given_scenario_ids,' +
    'selected_scenario_ids) VALUES (?, ?, ?, ?);';
  let given = scenarios.map(item => item.id);
  given = JSON.stringify(given);
  let selected = JSON.stringify([]);
  await db.run(newBoard, [gameID, playerID, given, selected]);
  await db.close();
}

/**
 * Creates an object containing the game state and returns it.
 * @param {string} gameID - The ID of the game.
 * @param {string} playerID - The ID of the player.
 * @param {string} playerName - The name of the player.
 * @param {object} scenarios - The list of scenarios.
 * @returns {object} The data of the game.
 */
function createGame(gameID, playerID, playerName, scenarios) {
  let game = {
    'game_id': gameID,
    'player': {
      'id': playerID,
      'name': playerName,
      'board': scenarios
    }
  };
  return game;
}

/**
 * Gets the ID of the player based on their name and creates a new ID for the player if they are
 * not already an existing player.
 * @param {string} name - The name of the player.
 * @returns {number} The ID of the player.
 */
async function playerQuery(name) {
  const db = await getDBConnection();
  let searchQuery = 'SELECT id FROM players WHERE name = (?);';
  let player = await db.all(searchQuery, name);
  if (player.length === 0) {
    let insertQuery = 'INSERT INTO players (name) VALUES (?);';
    await db.run(insertQuery, name);
    player = await db.all(searchQuery, name);
    return player[0].id;
  }
  await db.close();
  return player[0].id;
}

/**
 * Creates a new game inside the database and gets the ID of the game.
 * @returns {number} The ID of the game.
 */
async function gameQuery() {
  const db = await getDBConnection();
  let newGame = 'INSERT INTO games (winner) VALUES (NULL);';
  await db.run(newGame);
  let query = 'SELECT id FROM games ORDER BY id DESC LIMIT 1;';
  let gameID = await db.all(query);
  await db.close();
  return gameID[0].id;
}

/**
 * Randomizes and gets all of the scenarios needed for a game based on the given size of the board.
 * @param {string} size - The size of the board.
 * @returns {object} The list of randomized scenarios.
 */
async function getScenarios(size) {
  const db = await getDBConnection();
  let freeQuery = 'SELECT * FROM scenarios WHERE id = "1" LIMIT 1;';
  let scenarioQuery = 'SELECT * FROM scenarios WHERE NOT id = "1" ORDER BY RANDOM()' +
    'LIMIT (?);';
  let scenarios = await db.all(scenarioQuery, size - 1);
  let free = await db.all(freeQuery);
  let allScenarios = free.concat(scenarios);
  await db.close();
  return allScenarios;
}

/**
 * Establishes a database connection to the wpl database and returns the database object.
 * Any errors that occur during con. should be caught in the function that calls this one.
 * @returns {object} - The database object for the connection.
 */
async function getDBConnection() {
  const db = await sqlite.open({
    filename: 'zoomingo.db',
    driver: sqlite3.Database
  });
  return db;
}

app.use(express.static('public'));
const PORT = process.env.PORT || 8000;
app.listen(PORT);