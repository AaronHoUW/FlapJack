/**
 * Jun Nguyen
 * November 22, 2020
 * CSE 154 AB AU20 - Austin Jenchi
 *
 * This is the backend (or "server side") for the Yippers website, where the
 * user's data and state of the website is stored in local files. It sends the "yips", or posts, of
 * every user registered to the frontend (or "client side").
 *
 * The Yipper API stores every yip created on its database and provides the data of each yip.
 * *** Endpoint Documentation ***
 * Endpoint: /yipper/yips
 * Query Parameters: search (optional)
 * Description: Provides the data of all the yips from every user as well as the yips matching
 * a given search term.
 * Request Type: GET
 * Response Type: JSON
 * Example Request: /yipper/yips
 * Example Response:
 *  {
 *    "yips": [
 *      {
 *        "id": 25,
 *        "name": "Mister Fluffers",
 *        "yip": "It is sooooo fluffy I am gonna die",
 *        "hashtag": "fluff",
 *        "likes": 6,
 *        "date": "2020-07-07 03:48:28"
 *      },
 *      ...
 *    ]
 *  }
 * Error Handling:
 * - Possible 500 (internal server error) errors (all plain text):
 *   - Responds with 'An error occurred on the server. Try again later.'
 * *************************************
 * Endpoint: /yipper/user/:user
 * Query Parameters: none
 * Description: Provides the yip data for a designated user.
 * Request Type: GET
 * Response Type: JSON
 * Example Request: /yipper/user/Chewbarka
 * Example Response:
 *  [
 *    {
 *      "name": "Chewbarka",
 *      "yip": "chewy or soft cookies. I chew them all",
 *      "hashtag": "largebrain",
 *      "date": "2020-07-09 22:26:38"
 *    },
 *    ...
 *  ]
 * Error Handling:
 * - Possible 400 (invalid request) errors (all plain text):
 *   - If the user is not an existing name in the Yipper database, respond with
 *     'Yikes. User does not exist.'
 * - Possible 500 (internal server error) errors (all plain text):
 *   - Responds with 'An error occurred on the server. Try again later.'
 * *************************************
 * Endpoint: /yipper/likes
 * Body Parameters: id
 * Description: Updates the likes for a designated yip. Increments the value by 1 and responds with
 * the new value.
 * Request Type: POST
 * Response Type: Plain Text
 * Example Request: /yipper/likes
 * Example Response:
 *  8
 * Error Handling:
 * - Possible 400 (invalid request) errors (all plain text):
 *   - If the ID is not an existing ID in the Yipper database, respond with
 *     'Yikes. ID does not exist.'
 *   - If missing the ID parameter, respond with 'Missing one or more of the required params.'
 * - Possible 500 (internal server error) errors (all plain text):
 *   - Responds with 'An error occurred on the server. Try again later.'
 * *************************************
 * Endpoint: /yipper/new
 * Body Parameters: name and full
 * Description: Adds a new yip and its information to the database. Sends back all of the data
 * for that new yip.
 * Request Type: POST
 * Response Type: JSON
 * Example Request: /yipper/new
 * Example Response:
 *  {
 *    "id": 43,
 *    "name": "Chewbarka",
 *    "yip": "imagine waking up at 4pm...couldn't be me",
 *    "hashtag": "tired",
 *    "likes": 0,
 *    "date": "2020-11-25 19:21:43"
 *  }
 * Error Handling:
 * - Possible 400 (invalid request) errors (all plain text):
 *   - If the user is not an existing name in the Yipper database, respond with
 *     'Yikes. User does not exist.'
 *   - If missing the name or full parameters, respond with 'Missing one or more of the
 *     required params.'
 * - Possible 500 (internal server error) errors (all plain text):
 *   - Responds with 'An error occurred on the server. Try again later.'
 */
"use strict";

const express = require("express");
const sqlite = require("sqlite");
const sqlite3 = require("sqlite3");
const app = express();
const multer = require("multer");

// for application/x-www-form-urlencoded
app.use(express.urlencoded({extended: true})); // built-in middleware
// for application/json
app.use(express.json()); // built-in middleware
// for multipart/form-data (required with FormData)
app.use(multer().none()); // requires the "multer" module

const SERVER_ERROR_CODE = 500;
const CLIENT_ERROR_CODE = 400;

/**
 * Gets all of the yips from every user on the website and/or the yips matching a given search term.
 * Sends the yip data from the database back to the client.
 */
app.get("/yipper/yips", async function(req, res) {
  const db = await getDBConnection();
  let search = req.query['search'];
  try {
    let query = '';
    if (!search) {
      query = 'SELECT * FROM yips ORDER BY DATETIME(date) DESC;';
    } else {
      query = 'SELECT id FROM yips WHERE yip LIKE "%' + search + '%";';
    }
    let yips = await queryYips(query);
    res.json(yips);
  } catch (error) {
    res.status(SERVER_ERROR_CODE).send("An error occurred on the server. Try again later.");
  }

  await db.close();
});

/**
 * Gets all of the yips for a certain user on the website. Sends the yip data of that user back to
 * the client.
 */
app.get("/yipper/user/:user", async function(req, res) {
  const db = await getDBConnection();
  let user = req.params['user'];
  try {
    let query = 'SELECT name, yip, hashtag, date FROM yips WHERE name="' + user +
      '" ORDER BY DATETIME(date) DESC;';
    let data = await queryData(query);
    if (!data.length) {
      res.type("text")
        .status(CLIENT_ERROR_CODE)
        .send("Yikes. User does not exist.");
    } else {
      res.json(data);
    }
  } catch (error) {
    res.status(SERVER_ERROR_CODE).send("An error occurred on the server. Try again later.");
  }

  await db.close();
});

/**
 * Retrieves the current number of likes on a yip and updates it. Sends back the new number of likes
 * of that yip.
 */
app.post("/yipper/likes", async function(req, res) {
  const db = await getDBConnection();
  res.type("text");
  let id = req.body.id;

  if (id) {
    try {
      let exist = await getIfExists("id", "", id);
      if (!exist) {
        res.status(CLIENT_ERROR_CODE).send("Yikes. ID does not exist.");
      } else {
        let likes = await getLikes(id);
        res.send(String(likes));
      }
    } catch (error) {
      res.status(SERVER_ERROR_CODE).send("An error occurred on the server. Try again later.");
    }
  } else {
    res.status(CLIENT_ERROR_CODE).send("Missing one or more of the required params.");
  }

  await db.close();
});

/**
 * Saves the data of a new yip created from the client. Sends back the new yip's data in the same
 * format as every other yip on the website.
 */
app.post("/yipper/new", async function(req, res) {
  const db = await getDBConnection();
  let name = req.body.name;
  let full = req.body.full;

  if (name && full) {
    try {
      let exist = await getIfExists("name", name, "");
      if (!exist) {
        res.type("text")
          .status(CLIENT_ERROR_CODE)
          .send("Yikes. User does not exist.");
      } else {
        let newYip = await getNewYip(name, full);
        res.json(newYip[0]);
      }
    } catch (error) {
      res.status(SERVER_ERROR_CODE).send("An error occurred on the server. Try again later.");
    }
  } else {
    res.type("text")
      .status(CLIENT_ERROR_CODE)
      .send("Missing one or more of the required params.");
  }

  await db.close();
});

/**
 * Checks if the name or ID already exists in the database. Sends back data of the yip if the ID or
 * user exists.
 * @param {string} nameOrID - Name or ID to check for.
 * @param {string} name - The name of the user.
 * @param {string} id - The ID of the yip.
 * @returns {boolean} Whether or not the name or ID exists.
 */
async function getIfExists(nameOrID, name, id) {
  const db = await getDBConnection();
  let list = await checkExists(nameOrID);
  let exist = false;
  await list.forEach(element => {
    if (name && name !== "") {
      if (element.name === name) {
        exist = true;
      }
    }
    if (id && id !== "") {
      if (element.id === Number(id)) {
        exist = true;
      }
    }
  });

  await db.close();
  return exist;
}

/**
 * Updates the number of likes and sends back the yip's likes data to the client.
 * @param {string} id - The ID of the yip.
 * @returns {number} The number of likes of the yip.
 */
async function getLikes(id) {
  const db = await getDBConnection();
  await updateLikes(id);
  let query = 'SELECT likes FROM yips WHERE id="' + id + '" LIMIT 1;';
  let data = await db.all(query);
  let yip = data[0].likes;
  await db.close();
  return yip;
}

/**
 * Adds the new yip to the database and sends back the data of the new yip to the client.
 * @param {string} name - The name of the user.
 * @param {string} full - The contents of the yip.
 * @returns {array} The array containing data about the new yip.
 */
async function getNewYip(name, full) {
  const db = await getDBConnection();
  let newYip = await addYip(name, full);
  let query = 'SELECT * FROM yips WHERE id="' + newYip.lastID + '";';
  let data = await db.all(query);
  await db.close();
  return data;
}

/**
 * Queries the database for all of the distinct names or IDs. Returns the list of entries in the
 * database with distinct names or IDs.
 * @param {string} nameOrID - The names or IDs to check for distinction.
 * @returns {array} The list of distinct names or IDs.
 */
async function checkExists(nameOrID) {
  const db = await getDBConnection();
  let query = 'SELECT DISTINCT ' + nameOrID + ' FROM yips';
  let existingList = await db.all(query);
  await db.close();
  return existingList;
}

/**
 * Inserts the new yip into the database. Returns the data of the new yip.
 * @param {string} name - The name of the user.
 * @param {string} full - The contents of the yip.
 * @returns {object} The object that contains data of the new yip.
 */
async function addYip(name, full) {
  const db = await getDBConnection();
  let query = 'INSERT into yips ("name", "yip", "hashtag", "likes")' +
    ' VALUES ($name, $yip, $hashtag, $likes);';

  let yip = await db.run(query, {
    $name: name,
    $yip: full.split("#")[0].trim(),
    $hashtag: full.split("#")[1],
    $likes: 0
  });

  await db.close();
  return yip;
}

/**
 * Query the database to get all the yips and returns the object with all the yips.
 * @param {string} query - The query string.
 * @returns {object} The object with all the yips' data.
 */
async function queryYips(query) {
  const db = await getDBConnection();
  let data = await queryData(query);
  let allYips = {
    yips: data
  };
  await db.close();
  return allYips;
}

/**
 * Updates the number of likes of a yip in the database.
 * @param {string} id - The ID of the yip.
 */
async function updateLikes(id) {
  const db = await getDBConnection();
  let update = 'UPDATE yips SET likes = likes + 1 WHERE id="' + id + '";';
  await db.all(update);
  await db.close();
}

/**
 * Query the database and returns the data that was queried.
 * @param {string} query - The query string.
 * @returns {array} The data that was queried from the database.
 */
async function queryData(query) {
  const db = await getDBConnection();
  let data = await db.all(query);
  await db.close();
  return data;
}

/**
 * Establishes a database connection to the wpl database and returns the database object.
 * Any errors that occur during con. should be caught in the function that calls this one.
 * @returns {object} - The database object for the connection.
 */
async function getDBConnection() {
  const db = await sqlite.open({
    filename: 'yipper.db',
    driver: sqlite3.Database
  });
  return db;
}

app.use(express.static('public'));
const PORT = process.env.PORT || 8000;
app.listen(PORT);