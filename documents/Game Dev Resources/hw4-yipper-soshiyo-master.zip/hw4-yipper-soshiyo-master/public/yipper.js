/**
 * Jun Nguyen
 * November 22, 2020
 * CSE 154 AB AU20 - Austin Jenchi
 *
 * This is the frontend (or "client side") for the Yippers website. It allows the user to browse
 * through all the yips ever created on their feed, search for yips, create a yip, like yips, and
 * view another user's profile.
 */
"use strict";

(function() {
  const BASE_URL = "/yipper";

  window.addEventListener("load", init);

  /**
   * Runs on page load. Sets up the user's feed with all the yips by every user, and sets up
   * the website to allow the user to interact with it.
   */
  function init() {
    fetchGet("/yips", showYips);

    id("search-term").addEventListener("input", checkSearchBar);
    id("search-btn").addEventListener("click", searchResult);

    id("home-btn").addEventListener("click", displayHome);

    id("yip-btn").addEventListener("click", addYipView);

    qs("form").addEventListener("submit", event => {
      event.preventDefault();
      createYip();
    });
  }

  /**
   * Shows the view for when the user wants to create their own yip.
   */
  function addYipView() {
    hide("user");
    hide("home");
    show("new");
  }

  /**
   * Creates a yip once the player submits their yip. Sends the yip data to the server and
   * displays the yip on the page.
   */
  function createYip() {
    let params = new FormData();
    params.append("name", id("name").value);
    params.append("full", id("yip").value);
    let url = BASE_URL + "/new";
    fetch(url, {method: "POST", body: params})
      .then(checkStatus)
      .then(res => res.json())
      .then(displayYip)
      .catch(handleError);
  }

  /**
   * Displays the newly created yip on the page, created by the user. Sets a timer to switch to the
   * home page after a couple seconds of creating the yip.
   * @param {object} res - The data of the yip that was created.
   */
  function displayYip(res) {
    id("name").value = "";
    id("yip").value = "";
    let {id: yipID, name, yip, hashtag, date, likes} = res;

    let newYip = makeNewYip(yipID, name, yip, hashtag, date, likes);

    id("home").prepend(newYip);

    qsa(".meta div img").forEach(element => {
      element.addEventListener("click", updateLikes);
    });

    setTimeout(() => {
      show("home");
      hide("new");
    }, 2000);
  }

  /**
   * Creates a container for the yip and returns the container with the yip's contents appended to
   * it.
   * @param {string} id - The ID of the yip.
   * @param {string} name - The name of the user.
   * @param {string} newYip - The contents of the yip.
   * @param {string} hashtag - The hashtag of the yip.
   * @param {string} date - The date that the yip was created.
   * @param {string} likes - The number of likes on the yip.
   * @returns {HTMLElement} The yip post with all of its contents.
   */
  function makeNewYip(id, name, newYip, hashtag, date, likes) {
    let yip = gen("article");
    yip.classList.add("card");
    yip.id = id;

    let img = gen("img");
    img.src = editName("img/" + name) + ".png";
    img.alt = name;

    yip.appendChild(img);
    firstDiv(yip, name, newYip, hashtag);
    secondDiv(yip, date, likes);

    return yip;
  }

  /**
   * Displays the user's profile when clicked on.
   */
  function displayUser() {
    hide("home");
    hide("new");
    show("user");
    if (qs(".single")) {
      qs(".single").remove();
    }

    let url = "/user/" + this.textContent;
    fetchGet(url, createProfile);
  }

  /**
   * Creates the user's profile based on the data received from the server. Displays the user's
   * profile.
   * @param {object} res - The data of the user's profile.
   */
  function createProfile(res) {
    let name = res[0].name;
    let article = gen("article");
    article.classList.add("single");
    let h2 = gen("h2");
    h2.textContent = "Yips shared by " + name + ":";

    let count = 1;
    res.forEach(element => {
      let p = gen("p");
      p.textContent = "Yip " + count + ": " + element.yip + " #" + element.hashtag;
      h2.appendChild(p);
      count++;
    });

    article.appendChild(h2);
    id("user").appendChild(article);
  }

  /**
   * Displays the home page with all the yips posted.
   */
  function displayHome() {
    hide("user");
    hide("new");
    show("home");
    id("search-term").value = "";
    let cards = qsa("article.card");
    cards.forEach(element => {
      element.classList.remove("hidden");
    });
  }

  /**
   * Gets the results when the player searches for a term.
   */
  function searchResult() {
    show("home");
    hide("user");
    hide("new");
    hide("error");

    let url = "/yips?search=" + id("search-term").value.trim();
    fetchGet(url, displayResult);
  }

  /**
   * Displays the result of the search on the page.
   * @param {object} res - The yips that have the search term in it.
   */
  function displayResult(res) {
    id("search-btn").disabled = true;
    let yips = res.yips;
    let cards = qsa("article.card");

    Array.from(cards).forEach(el => hide(el.id));

    yips.forEach(yip => show(yip.id));
  }

  /**
   * Checks if the search bar has content or not. If it does, then enable the search button, and
   * vice versa.
   */
  function checkSearchBar() {
    let search = id("search-term").value;
    if (search.trim() === "") {
      id("search-btn").disabled = true;
    } else {
      id("search-btn").disabled = false;
    }
  }

  /**
   * Shows all the yips on the page. Allows for the like buttons to be clicked on.
   * @param {object} response - The object containing all of the yips' data.
   */
  function showYips(response) {
    let allYips = response.yips;
    hide("error");
    for (let i = 0; i < allYips.length; i++) {
      let {id: yipID, name, yip, hashtag, date, likes} = allYips[i];

      let newYip = makeNewYip(yipID, name, yip, hashtag, date, likes);

      id("home").appendChild(newYip);
    }

    qsa(".meta div img").forEach(element => {
      element.addEventListener("click", updateLikes);
    });
  }

  /**
   * Creates the first part of the yip post, containing the user's name and the contents of their
   * yip post.
   * @param {HTMLElement} article - The container of the yip post.
   * @param {string} name - The name of the user.
   * @param {string} yip - The contents of the yip post.
   * @param {string} hashtag - The hashtag of the yip post.
   */
  function firstDiv(article, name, yip, hashtag) {
    let div = gen("div");
    let p1 = gen("p");
    let p2 = gen("p");

    p1.classList.add("individual");
    p1.textContent = name;
    p2.textContent = yip + " #" + hashtag;
    div.appendChild(p1);
    div.appendChild(p2);
    article.appendChild(div);

    qsa(".individual").forEach(element => {
      element.addEventListener("click", displayUser);
    });
  }

  /**
   * Creates the second part of the yip post, containing the meta data like date created and number
   * of likes of a yip post.
   * @param {HTMLElement} article - The container of the yip post.
   * @param {number} date - The date that the yip was created.
   * @param {number} likeNumber - The number of likes of the yip.
   */
  function secondDiv(article, date, likeNumber) {
    let div = gen("div");
    let p = gen("p");
    let div2 = gen("div");

    div.classList.add("meta");
    let datePosted = new Date(date).toLocaleString();
    p.textContent = datePosted;
    getLikes(div2, likeNumber);

    div.appendChild(p);
    div.appendChild(div2);
    article.appendChild(div);
  }

  /**
   * Gets the number of likes of a yip and displays it on the page.
   * @param {HTMLElement} container - The HTML element that contains the likes data.
   * @param {number} likeCount - The number of likes total of a yip.
   */
  function getLikes(container, likeCount) {
    let img = gen("img");
    let p = gen("p");

    img.src = "img/heart.png";
    img.alt = "heart icon";
    p.textContent = likeCount;

    container.appendChild(img);
    container.appendChild(p);
  }

  /**
   * Helper function to edit the name of the user to put it in the proper image source format.
   * @param {string} name - The name of the user to edit.
   * @returns {string} The name of the user after editing.
   */
  function editName(name) {
    name = name.replace(/\s+/g, '-').toLowerCase();
    return name;
  }

  /**
   * Updates the number of likes on a yip post. Sends the ID of the yip to the server to update.
   */
  function updateLikes() {
    let params = new FormData();
    let id = this.parentNode.parentNode.parentNode.id;
    let totalLikes = this.nextSibling;
    params.append("id", id);

    let url = BASE_URL + "/likes";
    fetch(url, {method: "POST", body: params})
      .then(checkStatus)
      .then(res => res.text())
      .then((likes) => {
        totalLikes.textContent = likes;
      })
      .catch(handleError);
  }

  /**
   * Helper function to fetch data and return it in JSON format.
   * @param {string} getURL - The url to fetch data from.
   * @param {function} process - Uses the response data and processes it.
   */
  function fetchGet(getURL, process) {
    let url = BASE_URL + getURL;
    fetch(url)
      .then(checkStatus)
      .then(res => res.json())
      .then(process)
      .catch(handleError);
  }

  /**
   * Handles the possible errors returned by the API. If an error occurs, show the error text and
   * disable the page buttons.
   */
  function handleError() {
    hide("yipper-data");
    show("error");
    qsa("nav button").forEach(element => {
      element.disabled = true;
    });
  }

  /**
   * Helper function to hide parts of the game.
   * @param {object} object - The object to be hidden.
   */
  function hide(object) {
    id(object).classList.add("hidden");
  }

  /**
   * Helper function to show parts of the game.
   * @param {object} object - The object to be shown.
   */
  function show(object) {
    id(object).classList.remove("hidden");
  }

  /**
   * Helper function to return the response's result text if successful, otherwise
   * returns the rejected Promise result with an error status and corresponding text
   * @param {object} res - response to check for success/error
   * @return {object} - valid response if response was successful, otherwise rejected
   *                    Promise result
   */
  async function checkStatus(res) {
    if (!res.ok) {
      throw new Error(await res.text());
    }
    return res;
  }

  /**
   * Returns the DOM element with the given ID.
   * @param {string} idName - The ID to find.
   * @returns {object} DOM object associated with id (null if not found).
   */
  function id(idName) {
    return document.getElementById(idName);
  }

  /**
   * Returns first element matching selector.
   * @param {string} selector - CSS query selector.
   * @returns {HTMLElement} - DOM object associated selector.
   */
  function qs(selector) {
    return document.querySelector(selector);
  }

  /**
   * Returns the array of elements that match the given CSS selector.
   * @param {string} query - CSS query selector
   * @returns {object[]} array of DOM objects matching the query.
   */
  function qsa(query) {
    return document.querySelectorAll(query);
  }

  /**
   * Returns a new element that is generated from the given element type.
   * @param {string} elType - HTML element type for new DOM element.
   * @returns {object} New DOM object for given HTML tag.
   */
  function gen(elType) {
    return document.createElement(elType);
  }
})();