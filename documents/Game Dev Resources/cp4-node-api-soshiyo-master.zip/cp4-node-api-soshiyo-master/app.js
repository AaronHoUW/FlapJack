/**
 * Jun Nguyen
 * November 17, 2020
 * CSE 154 AB AU20 - Austin Jenchi
 *
 * This is the backend (or "server side") for the Delusion World Visual Novel game, where the
 * player's data is stored in local files. It also sends the dialogue to the frontend (or "client
 * side") for the player to see.
 */

"use strict";

const express = require("express");
const app = express();
const fs = require("fs").promises;
const multer = require("multer");

// for application/x-www-form-urlencoded
app.use(express.urlencoded({extended: true})); // built-in middleware
// for application/json
app.use(express.json()); // built-in middleware
// for multipart/form-data (required with FormData)
app.use(multer().none()); // requires the "multer" module

const USER_INFO_FILE = "user-info.json";
const DIALOGUE_FILE = "dialogue.json";
const SERVER_ERROR_CODE = 500;
const CLIENT_ERROR_CODE = 400;

/**
 * Requests that a new player is added to the user info file. This will retrieve the current state
 * of the user info file and update it with the new player's name, username, and avatar to be added.
 */
app.post("/player", async (req, res) => {
  let name = req.body.name;
  let username = req.body.username;
  let avatar = req.body.avatar;

  res.type("text");
  if (name && username && avatar) {
    try {
      let info = await read(USER_INFO_FILE);
      info[username] = {
        "player-name": name,
        "avatar-sprite": avatar
      };
      await fs.writeFile(USER_INFO_FILE, JSON.stringify(info));
      res.send("Information saved!");
    } catch (error) {
      res.status(SERVER_ERROR_CODE).send(catchError(error));
    }
  } else {
    res.status(CLIENT_ERROR_CODE).send("Missing required parameters");
  }
});

/**
 * Gets all of the dialogue for the visual novel. Sends the data from the dialogue file back to
 * the client.
 */
app.get("/dialogue", async (req, res) => {
  try {
    let dialogue = await read(DIALOGUE_FILE);
    res.json(dialogue);
  } catch (error) {
    res.status(SERVER_ERROR_CODE).send(catchError(error));
  }
});

/**
 * Reads the given file and sends back the data after it has been parsed.
 * @param {string} fileName - The file's name to be read.
 * @returns {object} The file after it has been parsed.
 */
async function read(fileName) {
  let data = await fs.readFile(fileName, "utf8");
  data = JSON.parse(data);
  return data;
}

/**
 * Catches the error when an error is thrown. Returns a message about the error depending on the
 * error code.
 * @param {object} err - The object that contains the error.
 * @returns {string} The error message depending on the error code.
 */
function catchError(err) {
  if (err.code === "ENOENT") {
    return "File does not exist";
  } else {
    return "Something went wrong on the server";
  }
}

app.use(express.static('public'));
const PORT = process.env.PORT || 8000;
app.listen(PORT);