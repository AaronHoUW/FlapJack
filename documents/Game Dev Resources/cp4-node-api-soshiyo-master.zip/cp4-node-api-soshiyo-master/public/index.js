/**
 * Jun Nguyen
 * November 17, 2020
 * CSE 154 AB AU20 - Austin Jenchi
 *
 * This is the client-side script for my visual novel.
 * It handles the player's progress through the story. Player gets options to
 * respond to the characters' dialogue. Allows the user to interact with the story.
 */

"use strict";
(function() {
  const TALK_SPEED = 10;
  let speechTimer = 0;
  let position = 0;
  let playerName;
  let username;
  let gender;

  window.addEventListener("load", init);

  /**
   * Runs on page load. Sets up the buttons to start and progress through the visual novel. Allows
   * player to choose their responses to the characters.
   */
  function init() {
    id("start-btn").addEventListener("click", () => hide("start-menu"));
    id("start-btn").addEventListener("click", () => show("name-menu"));

    qs("#name-menu form").addEventListener("submit", (event) => {
      event.preventDefault();
      hide("name-menu");
      show("username-menu");
    });

    qs("#username-menu form").addEventListener("submit", (event) => {
      event.preventDefault();
      hide("username-menu");
      show("character-menu");
    });

    qsa(".select-btn").forEach(element => {
      element.addEventListener("click", savePlayerAvatar);
    });

    id("dialogue-box").addEventListener("click", getDialogue);

    id("choice1").addEventListener("click", getDialogue);
    id("choice2").addEventListener("click", getDialogue);
  }

  /**
   * Makes a request to the server to get the dialogue for the story. Updates the dialogue whenever
   * the player clicks to advance the story.
   */
  function getDialogue() {
    fetch("/dialogue")
      .then(checkStatus)
      .then(res => res.json())
      .then(hide("options"))
      .then(updateDialogue)
      .catch(handleError);
  }

  /**
   * Processes the response from the server and updates the dialogue accordingly. Displays each
   * dialogue line on the page with the character speaking and their respective sprites.
   * @param {object} response - The response from the server that contains data about the dialogue.
   */
  function updateDialogue(response) {
    let speaker = response[position].speaker;
    let dialogue = playerDialogue(response[position].dialogue);
    let user = response[position].user;
    show("dialogue-box");
    show("sprite");
    if (position < 134) {
      if (speaker === "player") {
        speaker = username;
        user = gender;
      }
    } else {
      if (speaker === "player") {
        speaker = playerName;
        user = gender;
      }
    }

    if (position < response.length) {
      conversation(speaker, dialogue);
      changeSprite(user);
    }

    changeDisplay(response, speaker);
    if (position === response.length - 1) {
      finalScreen(position);
    }

    updateBackground(0, "start-bg", "hub-bg");
    position++;
  }

  /**
   * Updates the dialogue whenever the player's name or username is mentioned. Replaces the
   * placeholders with the player's name or username.
   * @param {string} dialogue - String containing the dialogue sentence(s).
   * @returns {string} Resulting dialogue after the placeholders have been replaced.
   */
  function playerDialogue(dialogue) {
    if (dialogue.includes("[username]")) {
      dialogue = dialogue.replace("[username]", username);
    }

    if (dialogue.includes("[name]")) {
      dialogue = dialogue.replace("[name]", playerName);
    }

    return dialogue;
  }

  /**
   * When the player gets a choice as a response, displays the choices and hide the dialogue box.
   * @param {object} response - JSON object that contains data about the dialogue.
   */
  function playerChoice(response) {
    if (position === 42) {
      show("options");
      hide("sprite");
      hide("dialogue-box");
      id("choice1").textContent = response[position].choices[0];
      id("choice2").textContent = response[position].choices[1];
    }
  }

  /**
   * Updates the display whenever the player gets a choice or if the location changes in the story.
   * @param {object} response - JSON object that contains data about the dialogue.
   */
  function changeDisplay(response) {
    playerChoice(response);
    updateBackground(47, "hub-bg", "dungeon-bg");
    updateBackground(66, "dungeon-bg", "hub-bg");
    updateBackground(134, "hub-bg", "school-bg");
    updateBackground(190, "school-bg", "lunch-bg");
    updateBackground(208, "lunch-bg", "night-bg");
    updateBackground(223, "night-bg", "room-bg");
    updateBackground(227, "room-bg", "cafe-bg");
  }

  /**
   * Updates the background whenever the location changes in the story.
   * @param {number} num - Where the player is in the story.
   * @param {string} prevBG - The background to remove.
   * @param {string} newBG - The background to add.
   */
  function updateBackground(num, prevBG, newBG) {
    if (position === num) {
      changeClass(prevBG, newBG);
    }
  }

  /**
   * Displays the end screen when the player finishes the visual novel.
   */
  function finalScreen() {
    position = 0;
    hide("dialogue-box");
    hide("sprite");
    changeClass("cafe-bg", "start-bg");
    qs("footer").classList.remove("hidden");
  }

  /**
   * Changes the class of the body by replacing the old class with the new class.
   * @param {string} oldClass - The old class to be replaced.
   * @param {string} newClass - The new class to replace the old class with.
   */
  function changeClass(oldClass, newClass) {
    qs("body").classList.remove(oldClass);
    qs("body").classList.add(newClass);
  }

  /**
   * Updates the sprite for the appropriate character. If the player is the speaker outside of
   * Delusion World, hide the sprite image.
   * @param {string} source - The character's name to update their sprite.
   */
  function changeSprite(source) {
    show("sprite");
    let sprite = gen("img");
    if (position < 134 || position >= 214 && position < 223) {
      spriteEdit(sprite, source, "'s avatar", "-avatar.png");
    } else {
      if (source === "male" || source === "female" || source === "player") {
        hide("sprite");
      } else {
        spriteEdit(sprite, source, "'s sprite", "-normal.png");
      }
    }
  }

  /**
   * Updates information about the character's sprite and displays it on the screen.
   * @param {HTMLElement} sprite - The image of the sprite.
   * @param {string} source - The character's name to update their sprite.
   * @param {string} alt - The alt text for the sprite image.
   * @param {string} src - The source for the image file.
   */
  function spriteEdit(sprite, source, alt, src) {
    sprite.src = "img/" + source + src;
    sprite.id = "current-avatar";
    sprite.alt = source + alt;
    id("sprite").replaceChild(sprite, id("current-avatar"));
  }

  /**
   * Shows the dialogue and makes the characters speak. Sets up a speech timer to animate in the
   * text for visual aesthetics.
   * @param {string} speaker - The name of the character speaking.
   * @param {string} dialogue - The dialogue that the character speaks.
   */
  function conversation(speaker, dialogue) {
    clearInterval(speechTimer);
    let text = id("text");
    let name = id("speaker");
    text.textContent = "";
    name.textContent = speaker;

    speechTimer = setInterval(function() {
      if (dialogue.length === 0) {
        clearInterval(speechTimer);
      } else {
        text.textContent = text.textContent + dialogue[0];
        dialogue = dialogue.slice(1, dialogue.length);
      }
    }, TALK_SPEED);
  }

  /**
   * Saves the player's avatar and their data. Sends their information to the server to update or
   * add if they don't already have their information on the server.
   */
  function savePlayerAvatar() {
    playerName = id("name").value;
    username = id("username").value;
    gender = this.parentNode.id;

    id("player-name").textContent = playerName;
    id("game-name").textContent = username;

    let params = new FormData();
    params.append("name", id("name").value);
    params.append("username", id("username").value);
    params.append("avatar", this.parentNode.id);
    fetch("/player", {method: "POST", body: params})
      .then(checkStatus)
      .then(res => res.text())
      .then(savedInfo)
      .then(() => hide("character-menu"))
      .then(() => show("dialogue-box"))
      .then(() => show("sprite"))
      .catch(handleError);
  }

  /**
   * Displays the response text when the player's data is successfully stored on the server.
   * @param {string} res - The response text of successful storage.
   */
  function savedInfo(res) {
    id("text").textContent = res;
  }

  /**
   * Handles errors in the case that contacting the server is not possible. Displays a message to
   * the user to let them know.
   */
  function handleError() {
    let message = gen("p");
    message.textContent = "There was an error with the server.";
    id("character-menu").appendChild(message);
  }

  /**
   * Helper function to return the response's result text if successful, otherwise
   * returns the rejected Promise result with an error status and corresponding text
   * @param {object} res - response to check for success/error
   * @return {object} - valid response if response was successful, otherwise rejected
   *                    Promise result
   */
  async function checkStatus(res) {
    if (!res.ok) {
      throw new Error(await res.text());
    }
    return res;
  }

  /**
   * Helper function to hide parts in the story.
   * @param {string} hiddenBox - The ID of the object to hide.
   */
  function hide(hiddenBox) {
    id(hiddenBox).classList.add("hidden");
  }

  /**
   * Helper function to show hidden parts in the story.
   * @param {string} hiddenBox - The ID of the hidden part
   */
  function show(hiddenBox) {
    id(hiddenBox).classList.remove("hidden");
  }

  /**
   * Returns the DOM element with the given ID.
   * @param {string} idName - The ID to find.
   * @returns {object} DOM object associated with id (null if not found).
   */
  function id(idName) {
    return document.getElementById(idName);
  }

  /**
   * Returns first element matching selector.
   * @param {string} selector - CSS query selector.
   * @returns {HTMLElement} - DOM object associated selector.
   */
  function qs(selector) {
    return document.querySelector(selector);
  }

  /**
   * Returns the array of elements that match the given CSS selector.
   * @param {string} query - CSS query selector
   * @returns {object[]} array of DOM objects matching the query.
   */
  function qsa(query) {
    return document.querySelectorAll(query);
  }

  /**
   * Returns a new element that is generated from the given element type.
   * @param {string} elType - HTML element type for new DOM element.
   * @returns {object} New DOM object for given HTML tag.
   */
  function gen(elType) {
    return document.createElement(elType);
  }
})();