# Delusion World API Documentation
The Delusion World API saves the player's information and provides the dialogue of the visual novel.

## Dialogue Endpoint
**Request Format:** /dialogue

**Request Type:** GET

**Returned Data Format**: JSON

**Description:** Gets the dialogue for the story with the speaker.

**Example Request:** /dialogue

**Example Response:**

```json
[
  {
    "speaker": "Lucien",
    "dialogue": "Hey!! Are you guys ready to go?",
    "user": "ruki"
  },
  {
    "speaker": "Jin",
    "dialogue": "Of course!",
    "user": "yuto"
  },
  ...
]
```

**Error Handling:**
- Possible 500 (internal server error) errors (all plain text):
  - If the file that stores player data is missing, an error is returned with the message: `File does not exist`
  - If any other problems occur, an error is returned with the message: `Something went wrong on the server`

## Save Player Data Endpoint
**Request Format:** /player endpoint with POST parameters of `avatar`, `name`, and `username`

**Request Type:** POST

**Returned Data Format**: Plain Text

**Description:** Given a valid player `avatar`, `name`, and `username` to send, the server will save the player's data.

**Example Request:** /player endpoint with POST parameters of `avatar = male`, `name = Jun`, and `username = soshiuwu`

**Example Response:**
```
Information saved!
```

**Error Handling:**
- Possible 400 (invalid request) errors (all plain text):
  - If missing the name, username, or avatar of the player, an error is returned with the message: `Missing required parameters`
- Possible 500 (internal server error) errors (all plain text):
  - If the file that stores player data is missing, an error is returned with the message: `File does not exist`
  - If any other problems occur, an error is returned with the message: `Something went wrong on the server`
